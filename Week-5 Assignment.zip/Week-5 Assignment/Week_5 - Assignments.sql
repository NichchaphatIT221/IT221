/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week5 Assignment */ 
/***************************/

/* A */
SELECT *
FROM dbo.Person;

/* B */
SELECT PersonID, Person.Name, Phone, Email
FROM dbo.Person;

/* C */
SELECT *
FROM dbo.Donations
WHERE DonationDate < '20201017';

/* D */
SELECT *
FROM dbo.Donations
WHERE Amount > 50;

/* E */
SELECT *
FROM dbo.Merchandise

/* F */
SELECT *
FROM dbo.Merchandise
WHERE QuantityOnHand > 5; 

/* G */
SELECT Merchandise.MerchandiseID, SalesOrderHeader.OrderDate, Person.PersonID, Name, Phone, Email
FROM dbo.Merchandise, dbo.SalesOrderHeader, dbo.Person
ORDER BY PersonID ASC;
