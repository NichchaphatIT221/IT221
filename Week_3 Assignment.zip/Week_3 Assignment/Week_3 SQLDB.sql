/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week3 Assignment */ 
/***************************/

/* A */
SELECT *
FROM dbo.PROJECT;

/* B */
SELECT ProjectID, PROJECT.Name, StartDate, EndDate
FROM dbo.PROJECT;

/* C */
SELECT *
FROM dbo.PROJECT
WHERE StartDate < '20080801';

/* D */
SELECT *
FROM dbo.PROJECT
WHERE EndDate is NULL;

/* E */
SELECT ProjectID, EMPLOYEE.EmployeeNumber, LastName, FirstName, Phone
FROM dbo.EMPLOYEE, dbo.ASSIGNMENT
WHERE ASSIGNMENT.EmployeeNumber = EMPLOYEE.EmployeeNumber;

/* F */
SELECT PROJECT.ProjectID, PROJECT.name, PROJECT.Department, ASSIGNMENT.EmployeeNumber, LastName, FirstName, Phone
FROM dbo.EMPLOYEE, dbo.ASSIGNMENT, dbo.PROJECT
WHERE ASSIGNMENT.EmployeeNumber = EMPLOYEE.EmployeeNumber and PROJECT.ProjectID = ASSIGNMENT.ProjectID

/* G */
SELECT PROJECT.ProjectID, PROJECT.name, PROJECT.Department, ASSIGNMENT.EmployeeNumber, LastName, FirstName, Phone
FROM dbo.EMPLOYEE, dbo.ASSIGNMENT, dbo.PROJECT
WHERE ASSIGNMENT.EmployeeNumber = EMPLOYEE.EmployeeNumber and PROJECT.ProjectID = ASSIGNMENT.ProjectID
ORDER BY ProjectID ASC;
