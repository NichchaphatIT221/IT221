SELECT *
FROM Class, Grade, Student
WHERE Class.ClassNumber = Grade.ClassNumber and Student.StudentNumber = Grade.StudentNumber;