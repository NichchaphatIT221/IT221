/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week6 Assignment */ 
/***************************/

/* Question No.4 */

CREATE TABLE [dbo].[CUSTOMER_01](
	[EmailAddress] [varchar](100) NOT NULL,
	[LastName] [varchar](25) NOT NULL,
	[FirstName] [varchar](25) NOT NULL,
 CONSTRAINT [PK_CUSTOMER_01] PRIMARY KEY CLUSTERED 
(