/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week6 Assignment */ 
/***************************/

/* Question No.8 */

CREATE TABLE [dbo].[SALE_01](
	[SaleID] [int] NOT NULL,
	[DateOfSale] [date] NOT NULL,
	[EmailAddress] [varchar](100) NOT NULL,
	[SaleAmount] [numeric](7, 2) NOT NULL,
 CONSTRAINT [PK_CUSTOMER_03] PRIMARY KEY CLUSTERED 
(
	[SaleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SALE_01]  WITH CHECK ADD  CONSTRAINT [FK_SALE_01_CUSTOMER_01] FOREIGN KEY([EmailAddress])
REFERENCES [dbo].[CUSTOMER_01] ([EmailAddress])
ON UPDATE CASCADE
GO

ALTER TABLE [dbo].[SALE_01] CHECK CONSTRAINT [FK_SALE_01_CUSTOMER_01]
GO
