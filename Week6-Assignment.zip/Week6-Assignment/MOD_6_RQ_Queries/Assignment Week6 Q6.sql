/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week6 Assignment */ 
/***************************/

/* Question No.6 */

CREATE TABLE [dbo].[CUSTOMER_03](
	[CustomerID] [int] NOT NULL,
	[EmailAddress] [varchar](100) NOT NULL,
	[LastName] [varchar](25) NOT NULL,
	[FirstName] [varchar](25) NOT NULL,
 CONSTRAINT [PK_CUSTOMER_03_1] PRIMARY KEY CLUSTERED 
(