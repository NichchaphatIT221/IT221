/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week6 Assignment */ 
/***************************/

/* Question No.7 */

CREATE TABLE [dbo].[CUSTOMER_04](
	[CustomerID] [int] NOT NULL,
	[EmailAddress] [varchar](100) NOT NULL,
	[LastName] [varchar](25) NOT NULL,
	[FirstName] [varchar](25) NOT NULL,
 CONSTRAINT [PK_CUSTOMER_04] PRIMARY KEY CLUSTERED 
(