/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week6 Assignment */ 
/***************************/

/* Question No.5 */

CREATE TABLE [dbo].[CUSTOMER_02](
	[CustomerID] [int] NOT NULL,
	[EmailAddress] [varchar](100) NOT NULL,
	[LastName] [varchar](25) NOT NULL,
	[FirstName] [varchar](25) NOT NULL,
 CONSTRAINT [PK_CUSTOMER_02] PRIMARY KEY CLUSTERED 
(