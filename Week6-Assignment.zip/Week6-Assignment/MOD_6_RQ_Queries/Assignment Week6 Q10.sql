/***************************/ 
/* Name: Nichchaphat    */       
/* Course Name IT221   */ 
/* Assignment #: Week6 Assignment */ 
/***************************/

/* Question No.10 */

INSERT INTO [dbo].[CUSTOMER_01]
           ([EmailAddress]
           ,[LastName]
           ,[FirstName])
     VALUES
           ('tukta@gmail.com','Tukta','Belding'),
		   ('William@gmail.com','William','Belding'),
		   ('Nichchaphat@gmail.com','Nichchaphat','Sommhai')